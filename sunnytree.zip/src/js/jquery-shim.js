// Shim for jQuery - uses WordPress global
const $ = window.jQuery;
export default $;
export { $ as jQuery };
