<?php
/**
 * Product Loop Start - Category Pages
 *
 * Uses Bootstrap row structure for category archive display.
 *
 * @package SunnyTree
 */

declare(strict_types=1);

defined('ABSPATH') || exit;
?>
<div class="sunny-product-container-cat">
    <div class="row product-row-cat">
