<?php
/**
 * Product Loop End - Category Pages
 *
 * Closes the Bootstrap row wrapper and container.
 *
 * @package SunnyTree
 */

declare(strict_types=1);

defined('ABSPATH') || exit;
?>
    </div>
</div>
